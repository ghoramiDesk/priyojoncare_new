import { Outlet, Link, createRootRoute, HeadContent, Scripts } from "@tanstack/react-router";

import appCss from "../styles.css?url";
import { AuthProvider } from "@/lib/auth";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { FloatingContact } from "@/components/FloatingContact";
import { SosButton } from "@/components/SosButton";
import { FaqBlogSection } from "@/components/FaqBlogSection";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Priyojon Care — Trusted Senior Care in Bangladesh" },
      { name: "description", content: "Priyojon Care connects Bangladeshi families with trusted senior care: residences, care homes, memory care, in-home nursing, and ICU setup." },
      { name: "author", content: "Priyojon Care" },
      { property: "og:title", content: "Priyojon Care — Trusted Senior Care in Bangladesh" },
      { property: "og:description", content: "Residences, care homes, memory care, and in-home nursing for Bangladeshi families." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Priyojon Care — Trusted Senior Care in Bangladesh" },
      { name: "twitter:description", content: "Residences, care homes, memory care, and in-home nursing for Bangladeshi families." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/da8ed193-a22c-4f78-91a8-dd8c86cd52f7/id-preview-c88ce613--4fcf8611-9395-47d4-ba7f-40d70b7c14ec.lovable.app-1776705760126.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/da8ed193-a22c-4f78-91a8-dd8c86cd52f7/id-preview-c88ce613--4fcf8611-9395-47d4-ba7f-40d70b7c14ec.lovable.app-1776705760126.png" },
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  return (
    <AuthProvider>
      <div className="flex min-h-screen flex-col">
        <SiteHeader />
        <main className="flex-1">
          <Outlet />
        </main>
        <FaqBlogSection />
        <SiteFooter />
      </div>
      <FloatingContact />
      {/* <SosButton /> */}
    </AuthProvider>
  );
}
